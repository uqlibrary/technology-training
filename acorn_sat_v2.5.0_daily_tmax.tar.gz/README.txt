ACORN-SAT v2.3 station data for 112 sites listed in acorn_sat_v2.3_stations.txt
Australian Bureau of Meteorology 

